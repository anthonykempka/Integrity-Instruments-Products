//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ADC_Log.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ADC_LOG_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_COMM_SETUP                  129
#define IDD_CONFIG_DIALOG               131
#define IDC_BEGIN                       1000
#define IDC_HALT                        1001
#define IDC_COMM_SETUP                  1002
#define IDC_BROWSE                      1003
#define IDC_COMPORT                     1003
#define IDC_FILENAME                    1004
#define IDC_BAUD_RATE                   1004
#define IDC_OFFSET                      1004
#define IDC_CONFIG                      1005
#define IDC_LAST_COMMAND                1006
#define IDC_LAST_RESPONSE               1007
#define IDC_RS485_Radio                 1007
#define IDC_SAMPLE_COUNT                1008
#define IDC_RS232_Radio                 1009
#define IDC_VREF                        1011
#define IDC_LOG_INTERVAL                1012
#define IDC_SAMPLE1                     1013
#define IDC_SAMPLE2                     1014
#define IDC_SAMPLE3                     1015
#define IDC_SAMPLE4                     1016
#define IDC_SAMPLE5                     1017
#define IDC_SAMPLE6                     1018
#define IDC_SAMPLE7                     1019
#define IDC_SAMPLE8                     1020
#define IDC_UNI_SAMPLE1                 1021
#define IDC_UNI_SAMPLE2                 1022
#define IDC_MODULE_ADDRESS              1022
#define IDC_UNI_SAMPLE3                 1023
#define IDC_UNI_SAMPLE4                 1024
#define IDC_UNI_SAMPLE5                 1025
#define IDC_UNI_SAMPLE6                 1026
#define IDC_UNI_SAMPLE7                 1027
#define IDC_UNI_SAMPLE8                 1028
#define IDC_FILTER                      1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
